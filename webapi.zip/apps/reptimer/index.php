<html>
<head>
  <style>
  body {
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #a0a0ff;
    font-family: roboto,tahoma,verdana,arial;
    font-size: 3em;
    width: 100vw;
    height: 100vh;
  }
  </style>
</head>
<body>
  <div>Die Verbindung funktioniert.</div>
</body>
</html>
